# Pycee
Welcome to Pycee, a tool that provides enhanced error messages for Python users in Sublimee Text 3!

# Installation
Please add all files to the Packages/User folder under your Sublime Text 3 installation and insure imported libraries are installed. Please update the location of Python site-packages directory and the path of the logging file used in the finish function.

Please note we have previously had issues with installing the plugin on other computer's and cannot guarantee that the plugin will work with the latest/specific version of Sublime Text.

# Usage
To use Pycee, simply build your code and view Sublime's console to see the results.
